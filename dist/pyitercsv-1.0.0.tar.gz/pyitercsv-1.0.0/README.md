# pyitercsv

usage: pyitercsv.py [-h] [-l FILELIST] [-s STRINGCOMMAND] [-f FILECOMMAND] [-e] [-d DELIMITER]

optional arguments:

  -h, --help show this help message and exit
  
  -l FILELIST, --filelist FILELIST filename csv
                        
  -s STRINGCOMMAND, --stringcommand STRINGCOMMAND string to execute with #con_number# in the string
                        
  -f FILECOMMAND, --filecommand FILECOMMAND file with string to execute with #col_number# in the strings
                        
  -e, --execute execute commands, add this option when you are sure what you are going to do
  
  -d DELIMITER, --delimiter DELIMITER delimiter default is,
